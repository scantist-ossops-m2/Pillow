#ifndef __QUANT_OCTREE_H__
#define __QUANT_OCTREE_H__

int quantize_octree(Pixel *,
          unsigned long,
          unsigned long,
          Pixel **,
          unsigned long *,
          unsigned long **,
          int);

#endif