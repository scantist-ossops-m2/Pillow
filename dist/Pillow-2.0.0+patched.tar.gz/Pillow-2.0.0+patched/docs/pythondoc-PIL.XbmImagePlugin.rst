=============================
The PIL.XbmImagePlugin Module
=============================

The PIL.XbmImagePlugin Module
=============================

**XbmImageFile** (class) [`# <#PIL.XbmImagePlugin.XbmImageFile-class>`_]
    Image plugin for X11 bitmaps.

    For more information about this class, see `*The XbmImageFile
    Class* <#PIL.XbmImagePlugin.XbmImageFile-class>`_.

The XbmImageFile Class
----------------------

**XbmImageFile** (class) [`# <#PIL.XbmImagePlugin.XbmImageFile-class>`_]
