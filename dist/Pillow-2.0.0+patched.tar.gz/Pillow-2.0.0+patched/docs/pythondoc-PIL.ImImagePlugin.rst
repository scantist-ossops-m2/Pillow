============================
The PIL.ImImagePlugin Module
============================

The PIL.ImImagePlugin Module
============================

**ImImageFile** (class) [`# <#PIL.ImImagePlugin.ImImageFile-class>`_]
    Image plugin for the IFUNC IM file format.

    For more information about this class, see `*The ImImageFile
    Class* <#PIL.ImImagePlugin.ImImageFile-class>`_.

The ImImageFile Class
---------------------

**ImImageFile** (class) [`# <#PIL.ImImagePlugin.ImImageFile-class>`_]
