============================
The PIL.ImageSequence Module
============================

The PIL.ImageSequence Module
============================

**Iterator(im)** (class) [`# <#PIL.ImageSequence.Iterator-class>`_]
    This class implements an iterator object that can be used to loop
    over an image sequence.

    For more information about this class, see `*The Iterator
    Class* <#PIL.ImageSequence.Iterator-class>`_.

The Iterator Class
------------------

**Iterator(im)** (class) [`# <#PIL.ImageSequence.Iterator-class>`_]
**\_\_init\_\_(im)**
[`# <#PIL.ImageSequence.Iterator.__init__-method>`_]

    *im*

