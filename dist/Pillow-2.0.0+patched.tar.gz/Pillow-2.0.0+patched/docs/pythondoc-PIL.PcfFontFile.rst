==========================
The PIL.PcfFontFile Module
==========================

The PIL.PcfFontFile Module
==========================

**PcfFontFile(fp)** (class) [`# <#PIL.PcfFontFile.PcfFontFile-class>`_]
    Font file plugin for the X11 PCF format.

    For more information about this class, see `*The PcfFontFile
    Class* <#PIL.PcfFontFile.PcfFontFile-class>`_.

The PcfFontFile Class
---------------------

**PcfFontFile(fp)** (class) [`# <#PIL.PcfFontFile.PcfFontFile-class>`_]
