==================================
The PIL.BufrStubImagePlugin Module
==================================

The PIL.BufrStubImagePlugin Module
==================================

**register\_handler(handler)**
[`# <#PIL.BufrStubImagePlugin.register_handler-function>`_]

    *handler*

