=============================
The PIL.PcxImagePlugin Module
=============================

The PIL.PcxImagePlugin Module
=============================

**PcxImageFile** (class) [`# <#PIL.PcxImagePlugin.PcxImageFile-class>`_]
    Image plugin for Paintbrush images.

    For more information about this class, see `*The PcxImageFile
    Class* <#PIL.PcxImagePlugin.PcxImageFile-class>`_.

The PcxImageFile Class
----------------------

**PcxImageFile** (class) [`# <#PIL.PcxImagePlugin.PcxImageFile-class>`_]
