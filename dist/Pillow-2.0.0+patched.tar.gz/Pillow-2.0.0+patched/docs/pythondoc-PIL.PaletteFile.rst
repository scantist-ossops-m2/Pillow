==========================
The PIL.PaletteFile Module
==========================

The PIL.PaletteFile Module
==========================

**PaletteFile(fp)** (class) [`# <#PIL.PaletteFile.PaletteFile-class>`_]
    File handler for Teragon-style palette files.

    For more information about this class, see `*The PaletteFile
    Class* <#PIL.PaletteFile.PaletteFile-class>`_.

The PaletteFile Class
---------------------

**PaletteFile(fp)** (class) [`# <#PIL.PaletteFile.PaletteFile-class>`_]
