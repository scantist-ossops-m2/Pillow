=============================
The PIL.WmfImagePlugin Module
=============================

The PIL.WmfImagePlugin Module
=============================

**register\_handler(handler)**
[`# <#PIL.WmfImagePlugin.register_handler-function>`_]

    *handler*

**WmfStubImageFile** (class)
[`# <#PIL.WmfImagePlugin.WmfStubImageFile-class>`_]
    Image plugin for Windows metafiles.

    For more information about this class, see `*The WmfStubImageFile
    Class* <#PIL.WmfImagePlugin.WmfStubImageFile-class>`_.

The WmfStubImageFile Class
--------------------------

**WmfStubImageFile** (class)
[`# <#PIL.WmfImagePlugin.WmfStubImageFile-class>`_]
