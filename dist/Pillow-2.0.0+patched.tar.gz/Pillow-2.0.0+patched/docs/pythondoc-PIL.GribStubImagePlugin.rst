==================================
The PIL.GribStubImagePlugin Module
==================================

The PIL.GribStubImagePlugin Module
==================================

**register\_handler(handler)**
[`# <#PIL.GribStubImagePlugin.register_handler-function>`_]

    *handler*

