=============================
The PIL.PngImagePlugin Module
=============================

The PIL.PngImagePlugin Module
=============================

**PngImageFile** (class) [`# <#PIL.PngImagePlugin.PngImageFile-class>`_]
    Image plugin for PNG images.

    For more information about this class, see `*The PngImageFile
    Class* <#PIL.PngImagePlugin.PngImageFile-class>`_.

The PngImageFile Class
----------------------

**PngImageFile** (class) [`# <#PIL.PngImagePlugin.PngImageFile-class>`_]
