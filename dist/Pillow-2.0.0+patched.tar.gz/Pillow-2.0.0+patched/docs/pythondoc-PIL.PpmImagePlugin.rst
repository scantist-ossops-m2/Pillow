=============================
The PIL.PpmImagePlugin Module
=============================

The PIL.PpmImagePlugin Module
=============================

**PpmImageFile** (class) [`# <#PIL.PpmImagePlugin.PpmImageFile-class>`_]
    Image plugin for PBM, PGM, and PPM images.

    For more information about this class, see `*The PpmImageFile
    Class* <#PIL.PpmImagePlugin.PpmImageFile-class>`_.

The PpmImageFile Class
----------------------

**PpmImageFile** (class) [`# <#PIL.PpmImagePlugin.PpmImageFile-class>`_]
