=============================
The PIL.MicImagePlugin Module
=============================

The PIL.MicImagePlugin Module
=============================

**MicImageFile** (class) [`# <#PIL.MicImagePlugin.MicImageFile-class>`_]
    Image plugin for Microsoft's Image Composer file format.

    For more information about this class, see `*The MicImageFile
    Class* <#PIL.MicImagePlugin.MicImageFile-class>`_.

The MicImageFile Class
----------------------

**MicImageFile** (class) [`# <#PIL.MicImagePlugin.MicImageFile-class>`_]
