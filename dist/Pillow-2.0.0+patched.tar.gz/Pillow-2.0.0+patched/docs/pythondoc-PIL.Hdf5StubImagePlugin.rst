==================================
The PIL.Hdf5StubImagePlugin Module
==================================

The PIL.Hdf5StubImagePlugin Module
==================================

**register\_handler(handler)**
[`# <#PIL.Hdf5StubImagePlugin.register_handler-function>`_]

    *handler*

