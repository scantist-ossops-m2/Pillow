=============================
The PIL.SunImagePlugin Module
=============================

The PIL.SunImagePlugin Module
=============================

**SunImageFile** (class) [`# <#PIL.SunImagePlugin.SunImageFile-class>`_]
    Image plugin for Sun raster files.

    For more information about this class, see `*The SunImageFile
    Class* <#PIL.SunImagePlugin.SunImageFile-class>`_.

The SunImageFile Class
----------------------

**SunImageFile** (class) [`# <#PIL.SunImagePlugin.SunImageFile-class>`_]
