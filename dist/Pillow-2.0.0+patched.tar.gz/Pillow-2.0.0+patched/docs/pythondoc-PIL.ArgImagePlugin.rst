=============================
The PIL.ArgImagePlugin Module
=============================

The PIL.ArgImagePlugin Module
=============================

**ArgImageFile** (class) [`# <#PIL.ArgImagePlugin.ArgImageFile-class>`_]
    Image plugin for the experimental Animated Raster Graphics format.

    For more information about this class, see `*The ArgImageFile
    Class* <#PIL.ArgImagePlugin.ArgImageFile-class>`_.

The ArgImageFile Class
----------------------

**ArgImageFile** (class) [`# <#PIL.ArgImagePlugin.ArgImageFile-class>`_]
