=================================
The PIL.XVThumbImagePlugin Module
=================================

The PIL.XVThumbImagePlugin Module
=================================

**XVThumbImageFile** (class)
[`# <#PIL.XVThumbImagePlugin.XVThumbImageFile-class>`_]
    Image plugin for XV thumbnail images.

    For more information about this class, see `*The XVThumbImageFile
    Class* <#PIL.XVThumbImagePlugin.XVThumbImageFile-class>`_.

The XVThumbImageFile Class
--------------------------

**XVThumbImageFile** (class)
[`# <#PIL.XVThumbImagePlugin.XVThumbImageFile-class>`_]
