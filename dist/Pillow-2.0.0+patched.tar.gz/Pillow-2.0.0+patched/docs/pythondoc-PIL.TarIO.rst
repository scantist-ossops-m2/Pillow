====================
The PIL.TarIO Module
====================

The PIL.TarIO Module
====================

**TarIO(tarfile, file)** (class) [`# <#PIL.TarIO.TarIO-class>`_]
    A file object that provides read access to a given member of a TAR
    file.

    For more information about this class, see `*The TarIO
    Class* <#PIL.TarIO.TarIO-class>`_.

The TarIO Class
---------------

**TarIO(tarfile, file)** (class) [`# <#PIL.TarIO.TarIO-class>`_]
**\_\_init\_\_(tarfile, file)**
[`# <#PIL.TarIO.TarIO.__init__-method>`_]

    *tarfile*
    *file*

