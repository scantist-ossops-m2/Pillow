=============================
The PIL.GbrImagePlugin Module
=============================

The PIL.GbrImagePlugin Module
=============================

**GbrImageFile** (class) [`# <#PIL.GbrImagePlugin.GbrImageFile-class>`_]
    Image plugin for the GIMP brush format.

    For more information about this class, see `*The GbrImageFile
    Class* <#PIL.GbrImagePlugin.GbrImageFile-class>`_.

The GbrImageFile Class
----------------------

**GbrImageFile** (class) [`# <#PIL.GbrImagePlugin.GbrImageFile-class>`_]
