=============================
The PIL.SgiImagePlugin Module
=============================

The PIL.SgiImagePlugin Module
=============================

**SgiImageFile** (class) [`# <#PIL.SgiImagePlugin.SgiImageFile-class>`_]
    Image plugin for SGI images.

    For more information about this class, see `*The SgiImageFile
    Class* <#PIL.SgiImagePlugin.SgiImageFile-class>`_.

The SgiImageFile Class
----------------------

**SgiImageFile** (class) [`# <#PIL.SgiImagePlugin.SgiImageFile-class>`_]
