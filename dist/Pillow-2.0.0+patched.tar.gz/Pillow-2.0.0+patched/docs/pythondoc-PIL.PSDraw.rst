=====================
The PIL.PSDraw Module
=====================

The PIL.PSDraw Module
=====================

**PSDraw(fp=None)** (class) [`# <#PIL.PSDraw.PSDraw-class>`_]
    Simple Postscript graphics interface.

    For more information about this class, see `*The PSDraw
    Class* <#PIL.PSDraw.PSDraw-class>`_.

The PSDraw Class
----------------

**PSDraw(fp=None)** (class) [`# <#PIL.PSDraw.PSDraw-class>`_]
