==================================
The PIL.FitsStubImagePlugin Module
==================================

The PIL.FitsStubImagePlugin Module
==================================

**register\_handler(handler)**
[`# <#PIL.FitsStubImagePlugin.register_handler-function>`_]

    *handler*

