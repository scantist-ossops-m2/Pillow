=======================
The PIL.ExifTags Module
=======================

The PIL.ExifTags Module
=======================

Module Contents
---------------

**GPSTAGS** (variable) [`# <#PIL.ExifTags.GPSTAGS-variable>`_]
**TAGS** (variable) [`# <#PIL.ExifTags.TAGS-variable>`_]
