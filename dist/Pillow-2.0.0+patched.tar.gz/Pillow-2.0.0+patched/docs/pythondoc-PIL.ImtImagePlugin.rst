=============================
The PIL.ImtImagePlugin Module
=============================

The PIL.ImtImagePlugin Module
=============================

**ImtImageFile** (class) [`# <#PIL.ImtImagePlugin.ImtImageFile-class>`_]
    Image plugin for IM Tools images.

    For more information about this class, see `*The ImtImageFile
    Class* <#PIL.ImtImagePlugin.ImtImageFile-class>`_.

The ImtImageFile Class
----------------------

**ImtImageFile** (class) [`# <#PIL.ImtImagePlugin.ImtImageFile-class>`_]
