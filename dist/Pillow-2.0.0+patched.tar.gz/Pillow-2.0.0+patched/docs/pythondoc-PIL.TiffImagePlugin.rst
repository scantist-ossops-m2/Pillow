==============================
The PIL.TiffImagePlugin Module
==============================

The PIL.TiffImagePlugin Module
==============================

**ImageFileDirectory(prefix="II")** (class)
[`# <#PIL.TiffImagePlugin.ImageFileDirectory-class>`_]
    Wrapper for TIFF IFDs.

    For more information about this class, see `*The ImageFileDirectory
    Class* <#PIL.TiffImagePlugin.ImageFileDirectory-class>`_.

**TiffImageFile** (class)
[`# <#PIL.TiffImagePlugin.TiffImageFile-class>`_]
    Image plugin for TIFF files.

    For more information about this class, see `*The TiffImageFile
    Class* <#PIL.TiffImagePlugin.TiffImageFile-class>`_.

The ImageFileDirectory Class
----------------------------

**ImageFileDirectory(prefix="II")** (class)
[`# <#PIL.TiffImagePlugin.ImageFileDirectory-class>`_]

The TiffImageFile Class
-----------------------

**TiffImageFile** (class)
[`# <#PIL.TiffImagePlugin.TiffImageFile-class>`_]
