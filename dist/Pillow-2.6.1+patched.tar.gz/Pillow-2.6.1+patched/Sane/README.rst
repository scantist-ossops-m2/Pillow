Python SANE module V1.1 (30 Sep. 2004)
================================================================================

The SANE module provides an interface to the SANE scanner and frame
grabber interface for Linux.  This module was contributed by Andrew
Kuchling and is extended and currently maintained by Ralph Heinkel
(rheinkel-at-email.de). If you write to me please make sure to have the
word 'SANE' or 'sane' in the subject of your mail, otherwise it might
be classified as spam in the future.


To build this module, type (in the Sane directory)::

	python setup.py build

In order to install the module type::

	python setup.py install


For some basic documentation please look at the file sanedoc.txt
The two demo_*.py scripts give basic examples on how to use the software.
